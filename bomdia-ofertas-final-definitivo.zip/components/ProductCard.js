export default function ProductCard({ product }) {
  return (
    <div className="border rounded-xl shadow p-4 flex flex-col items-center">
      <img src={product.image} alt={product.name} className="w-40 h-40 object-contain"/>
      <h2 className="mt-2 text-lg font-semibold text-center">{product.name}</h2>
      <p className="line-through text-gray-400">{product.oldPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
      <p className="text-red-600 font-bold">{product.newPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
      <a href={product.link} target="_blank" className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        Comprar
      </a>
    </div>
  );
}