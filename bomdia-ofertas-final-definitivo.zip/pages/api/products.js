export default async function handler(req, res) {
  const products = [
    {
      id: 1,
      name: "Apple iPhone 13 (128GB) - Luz das estrelas",
      oldPrice: 4999.9,
      newPrice: 4599.9,
      image: "https://m.media-amazon.com/images/I/41Zbbl4P+LL._AC_SX679_.jpg",
      link: "https://amzn.to/46n1EUG"
    },
    {
      id: 2,
      name: "Notebook Lenovo LOQ-e 15IAX9E Intel Core i5-12450HX 16GB 512GB SSD",
      oldPrice: 4999.0,
      newPrice: 4399.0,
      image: "https://m.media-amazon.com/images/I/61Zbbl4P+LL._AC_SX679_.jpg",
      link: "https://amzn.to/46n2EUG"
    }
  ];
  res.status(200).json(products);
}